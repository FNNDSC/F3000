#!/usr/bin/env python

#
# FYBORG3000
#

# standard imports
import os

# fyborg imports
from _core import *
from fy_register import FyRegister

workdir = '/chb/users/daniel.haehn/TMP/FYBORG3000/4543113/working'

options = lambda:0
options.input = os.path.join( workdir, 'diffusion.nii' )
#options.target = os.path.join( workdir, 'brain.nii' )
options.output = os.path.join( workdir, 'WORKINGVERSION' )
#options.smooth = False

# attach a temporary environment
# options.tempdir = Utility.setupEnvironment()

# print options.tempdir

# FyRegister.run( options )

# clean up temporary environment
# Utility.teardownEnvironment( options.tempdir )

options.diffusion = os.path.join( workdir, 'diffusion.nii' )
options.bvals = os.path.join( workdir, 'diffusion.mghdti.bvals' )
options.bvecs = os.path.join( workdir, 'diffusion.mghdti.bvecs' )

Reconstruction.reconstruct(options.diffusion, options.bvals, options.bvecs, options.output)

options.fa = os.path.join( options.output, 'fa.nii.gz' )
options.evecs = os.path.join( options.output, 'evecs.nii.gz' )

Reconstruction.streamlines( options.fa, options.evecs, os.path.join( options.output, 'tracks.trk' ) )
