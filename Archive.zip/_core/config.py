#
# FYBORG3000
#

ANTS_BIN_DIR = '/chb/arch/Linux64/packages/ANTs/current/bin/'
